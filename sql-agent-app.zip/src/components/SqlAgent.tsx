import { useEffect, useRef, useState } from "react";
import { Database, Play, Send, Table2, Terminal, Wrench } from "lucide-react";
import type { AgentMessage, ToolCall } from "@/lib/agent";
import { TOOLS, runAgent } from "@/lib/agent";
import { listTables, type TableInfo } from "@/lib/db";

const uid = () => Math.random().toString(36).slice(2, 10);

const SUGGESTIONS = [
  "What is the revenue by country?",
  "Who are the top customers?",
  "Which products sell best?",
  "Show monthly revenue trend",
  "Break down orders by status",
];

function ResultTable({ rows }: { rows: Record<string, unknown>[] }) {
  if (!rows.length) return <p className="text-sm text-muted-foreground">No rows returned.</p>;
  const cols = Object.keys(rows[0]!);
  return (
    <div className="overflow-x-auto rounded-md border border-border">
      <table className="w-full text-left text-sm">
        <thead className="bg-muted/60">
          <tr>
            {cols.map((c) => (
              <th key={c} className="whitespace-nowrap px-3 py-2 font-medium text-muted-foreground">
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.slice(0, 50).map((row, i) => (
            <tr key={i} className="border-t border-border/70">
              {cols.map((c) => (
                <td key={c} className="whitespace-nowrap px-3 py-2 font-mono text-[13px]">
                  {String(row[c] ?? "")}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ToolCallCard({ call }: { call: ToolCall }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-md border border-border bg-muted/40">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm"
      >
        <Wrench className="size-3.5 text-accent" />
        <span className="font-mono text-[13px] text-foreground">{call.tool}</span>
        <span className="truncate text-xs text-muted-foreground">
          {call.tool === "run_sql_query"
            ? "SELECT …"
            : Object.entries(call.input)
                .map(([k, v]) => `${k}=${String(v)}`)
                .join(" ")}
        </span>
        <span
          className={`ml-auto rounded-full px-2 py-0.5 text-[11px] ${
            call.status === "running"
              ? "bg-accent/20 text-accent"
              : call.status === "error"
                ? "bg-destructive/20 text-destructive"
                : "bg-primary/15 text-primary"
          }`}
        >
          {call.status === "running" ? "running" : call.status === "error" ? "error" : call.output}
        </span>
      </button>
      {open && (
        <div className="space-y-2 border-t border-border px-3 py-2">
          <pre className="overflow-x-auto rounded bg-background/70 p-2 text-[12px] text-muted-foreground">
            {JSON.stringify(call.input, null, 2)}
          </pre>
          {call.error && <p className="text-xs text-destructive">{call.error}</p>}
          {call.rows && <ResultTable rows={call.rows} />}
        </div>
      )}
    </div>
  );
}

export function SqlAgent() {
  const [tables, setTables] = useState<TableInfo[]>([]);
  const [messages, setMessages] = useState<AgentMessage[]>([
    {
      id: uid(),
      role: "agent",
      content:
        "Ask me anything about the sales database, or paste a SELECT statement. I inspect the schema with tools before writing SQL.",
    },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => setTables(listTables()), []);
  useEffect(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), [messages]);
  useEffect(() => {
    if (!busy) inputRef.current?.focus();
  }, [busy]);

  async function ask(question: string) {
    if (!question.trim() || busy) return;
    setBusy(true);
    setInput("");
    const agentId = uid();
    setMessages((m) => [
      ...m,
      { id: uid(), role: "user", content: question },
      { id: agentId, role: "agent", content: "" },
    ]);
    await runAgent(question, (partial) =>
      setMessages((m) => m.map((msg) => (msg.id === agentId ? { ...msg, ...partial } : msg))),
    );
    setBusy(false);
  }

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-7xl gap-6 px-4 py-8 lg:px-8">
      <aside className="hidden w-72 shrink-0 space-y-6 lg:block">
        <div>
          <h2 className="flex items-center gap-2 text-sm font-semibold">
            <Database className="size-4 text-primary" /> Schema
          </h2>
          <div className="mt-3 space-y-3">
            {tables.map((t) => (
              <div key={t.name} className="rounded-lg border border-border bg-card p-3">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 font-mono text-sm text-primary">
                    <Table2 className="size-3.5" />
                    {t.name}
                  </span>
                  <span className="text-xs text-muted-foreground">{t.rows} rows</span>
                </div>
                <ul className="mt-2 space-y-1">
                  {t.columns.map((c) => (
                    <li key={c.name} className="flex justify-between gap-2 text-xs">
                      <span className="font-mono text-foreground/90">{c.name}</span>
                      <span className="text-muted-foreground">{c.type}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h2 className="flex items-center gap-2 text-sm font-semibold">
            <Wrench className="size-4 text-accent" /> Tools
          </h2>
          <ul className="mt-3 space-y-2">
            {TOOLS.map((tool) => (
              <li key={tool.name} className="rounded-lg border border-border bg-card p-3">
                <p className="font-mono text-xs text-accent">{tool.name}</p>
                <p className="mt-1 text-xs text-muted-foreground">{tool.description}</p>
                <p className="mt-1 font-mono text-[11px] text-muted-foreground/70">{tool.input}</p>
              </li>
            ))}
          </ul>
        </div>
      </aside>

      <main className="flex min-w-0 flex-1 flex-col">
        <header className="mb-6">
          <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
            <Terminal className="size-6 text-primary" /> SQL Agent
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            A tool-using agent that inspects the schema, writes SQL, and runs it read-only against an in-browser
            database.
          </p>
        </header>

        <div className="flex-1 space-y-5">
          {messages.map((msg) =>
            msg.role === "user" ? (
              <div key={msg.id} className="flex justify-end">
                <p className="max-w-[80%] rounded-2xl rounded-br-sm bg-primary px-4 py-2 text-sm text-primary-foreground">
                  {msg.content}
                </p>
              </div>
            ) : (
              <div key={msg.id} className="space-y-3">
                {msg.thought && (
                  <p className="border-l-2 border-accent/60 pl-3 text-sm italic text-muted-foreground">
                    {msg.thought}
                  </p>
                )}
                {msg.toolCalls?.map((call) => <ToolCallCard key={call.id} call={call} />)}
                {msg.sql && (
                  <pre className="overflow-x-auto rounded-md border border-border bg-card p-3 text-[13px] text-primary">
                    {msg.sql}
                  </pre>
                )}
                {msg.content && <p className="text-sm leading-relaxed">{msg.content}</p>}
                {msg.rows && <ResultTable rows={msg.rows} />}
                {!msg.content && !msg.thought && busy && (
                  <p className="text-sm text-muted-foreground">Thinking…</p>
                )}
              </div>
            ),
          )}
          <div ref={bottomRef} />
        </div>

        <div className="sticky bottom-4 mt-6 space-y-3">
          <div className="flex flex-wrap gap-2">
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                type="button"
                disabled={busy}
                onClick={() => ask(s)}
                className="rounded-full border border-border bg-card px-3 py-1 text-xs text-muted-foreground transition-colors hover:border-primary hover:text-primary disabled:opacity-50"
              >
                {s}
              </button>
            ))}
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              ask(input);
            }}
            className="flex items-end gap-2 rounded-xl border border-border bg-card p-2"
          >
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  ask(input);
                }
              }}
              rows={2}
              placeholder="Ask a question or write SELECT * FROM orders…"
              className="min-h-[52px] flex-1 resize-none bg-transparent px-2 py-1 text-sm outline-none placeholder:text-muted-foreground"
            />
            <button
              type="submit"
              disabled={busy || !input.trim()}
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-opacity disabled:opacity-40"
            >
              {/^(select|with)\s/i.test(input.trim()) ? <Play className="size-4" /> : <Send className="size-4" />}
              {busy ? "Working…" : "Run"}
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}
