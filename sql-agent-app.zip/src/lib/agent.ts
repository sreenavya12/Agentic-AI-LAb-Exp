import { describeTable, listTables, runQuery } from "./db";

export type ToolName = "list_tables" | "describe_table" | "run_sql_query";

export type ToolCall = {
  id: string;
  tool: ToolName;
  input: Record<string, unknown>;
  status: "running" | "done" | "error";
  output?: string;
  rows?: Record<string, unknown>[];
  error?: string;
};

export type AgentMessage = {
  id: string;
  role: "user" | "agent";
  content: string;
  thought?: string;
  toolCalls?: ToolCall[];
  rows?: Record<string, unknown>[];
  sql?: string;
};

export const TOOLS: { name: ToolName; description: string; input: string }[] = [
  {
    name: "list_tables",
    description: "List every table in the database with row counts.",
    input: "{}",
  },
  {
    name: "describe_table",
    description: "Return the column names and types for one table.",
    input: '{ "table": string }',
  },
  {
    name: "run_sql_query",
    description: "Execute a read-only SELECT statement and return rows.",
    input: '{ "sql": string }',
  },
];

const uid = () => Math.random().toString(36).slice(2, 10);

function executeTool(tool: ToolName, input: Record<string, unknown>): Omit<ToolCall, "id" | "tool" | "input"> {
  try {
    if (tool === "list_tables") {
      const tables = listTables();
      return {
        status: "done",
        output: tables.map((t) => `${t.name} (${t.rows} rows)`).join(", "),
        rows: tables.map((t) => ({ table: t.name, rows: t.rows, columns: t.columns.length })),
      };
    }
    if (tool === "describe_table") {
      const table = describeTable(String(input['table']));
      return {
        status: "done",
        output: `${table.name}: ${table.columns.map((c) => c.name).join(", ")}`,
        rows: table.columns.map((c) => ({ column: c.name, type: c.type })),
      };
    }
    const rows = runQuery(String(input['sql']));
    return { status: "done", output: `${rows.length} row(s) returned`, rows };
  } catch (error) {
    return { status: "error", error: error instanceof Error ? error.message : String(error) };
  }
}

type Plan = { thought: string; sql: string; answer: (rows: Record<string, unknown>[]) => string };

const num = (v: unknown) => (typeof v === "number" ? v : Number(v ?? 0));

function planFor(question: string): Plan {
  const q = question.toLowerCase();

  if (/(revenue|sales|earn|money|total spent|income)/.test(q) && /(country|region)/.test(q)) {
    return {
      thought:
        "The question groups money by country. Revenue lives in orders (quantity) x products (price), and country is on customers, so I need a three-table join filtered to non-cancelled orders.",
      sql: `SELECT c.country, ROUND(SUM(o.quantity * p.price), 2) AS revenue, COUNT(o.id) AS orders
FROM orders o
JOIN customers c ON c.id = o.customer_id
JOIN products p ON p.id = o.product_id
WHERE o.status <> 'cancelled'
GROUP BY c.country
ORDER BY revenue DESC`,
      answer: (rows) =>
        rows.length
          ? `Revenue by country, highest first: ${rows
              .map((r) => `${r['country']} $${num(r['revenue']).toLocaleString()}`)
              .join("; ")}.`
          : "No revenue rows matched.",
    };
  }

  if (/(top|best|most)/.test(q) && /(customer|buyer|spender)/.test(q)) {
    return {
      thought:
        "This asks for a ranking of customers by spend. I'll join orders to products for line totals, exclude cancelled orders, and order the aggregate descending.",
      sql: `SELECT c.name AS customer, c.country, ROUND(SUM(o.quantity * p.price), 2) AS total_spent
FROM orders o
JOIN customers c ON c.id = o.customer_id
JOIN products p ON p.id = o.product_id
WHERE o.status <> 'cancelled'
GROUP BY c.name, c.country
ORDER BY total_spent DESC
LIMIT 5`,
      answer: (rows) =>
        rows.length
          ? `Top spender is ${rows[0]!['customer']} ($${num(rows[0]!['total_spent']).toLocaleString()}), followed by ${rows
              .slice(1)
              .map((r) => r['customer'])
              .join(", ")}.`
          : "No customers matched.",
    };
  }

  if (/(product|item)/.test(q) && /(top|best|popular|most sold|selling)/.test(q)) {
    return {
      thought:
        "Best-selling products means summing quantity per product. I'll join orders to products and rank by units sold.",
      sql: `SELECT p.name AS product, p.category, SUM(o.quantity) AS units, ROUND(SUM(o.quantity * p.price), 2) AS revenue
FROM orders o
JOIN products p ON p.id = o.product_id
WHERE o.status <> 'cancelled'
GROUP BY p.name, p.category
ORDER BY units DESC
LIMIT 5`,
      answer: (rows) =>
        rows.length
          ? `${rows[0]!['product']} leads with ${rows[0]!['units']} units ($${num(rows[0]!['revenue']).toLocaleString()} revenue).`
          : "No products matched.",
    };
  }

  if (/categor/.test(q)) {
    return {
      thought: "Category-level breakdown: aggregate revenue and units from orders joined to products.",
      sql: `SELECT p.category, SUM(o.quantity) AS units, ROUND(SUM(o.quantity * p.price), 2) AS revenue
FROM orders o
JOIN products p ON p.id = o.product_id
WHERE o.status <> 'cancelled'
GROUP BY p.category
ORDER BY revenue DESC`,
      answer: (rows) => `${rows.length} categories, led by ${rows[0]?.['category'] ?? "n/a"}.`,
    };
  }

  if (/(pending|cancel|status)/.test(q)) {
    return {
      thought: "The question is about order status, so I'll group the orders table by status.",
      sql: `SELECT o.status, COUNT(*) AS orders, SUM(o.quantity) AS units
FROM orders o
GROUP BY o.status
ORDER BY orders DESC`,
      answer: (rows) => `Order status breakdown: ${rows.map((r) => `${r['status']} ${r['orders']}`).join(", ")}.`,
    };
  }

  if (/(month|trend|over time|monthly)/.test(q)) {
    return {
      thought: "A time trend needs the order month. I'll take the first 7 characters of order_date and aggregate.",
      sql: `SELECT SUBSTRING(o.order_date, 1, 7) AS month, COUNT(*) AS orders, ROUND(SUM(o.quantity * p.price), 2) AS revenue
FROM orders o
JOIN products p ON p.id = o.product_id
WHERE o.status <> 'cancelled'
GROUP BY SUBSTRING(o.order_date, 1, 7)
ORDER BY month`,
      answer: (rows) => `Monthly revenue across ${rows.length} months, from ${rows[0]?.['month']} to ${rows.at(-1)?.['month']}.`,
    };
  }

  if (/customer/.test(q)) {
    return {
      thought: "A general customer question — read the customers table directly.",
      sql: `SELECT id, name, country, signup_date FROM customers ORDER BY signup_date`,
      answer: (rows) => `${rows.length} customers across ${new Set(rows.map((r) => r['country'])).size} countries.`,
    };
  }

  if (/product|price/.test(q)) {
    return {
      thought: "A catalogue question — read the products table sorted by price.",
      sql: `SELECT id, name, category, price FROM products ORDER BY price DESC`,
      answer: (rows) => `${rows.length} products, priced $${num(rows.at(-1)?.['price'])} to $${num(rows[0]?.['price'])}.`,
    };
  }

  return {
    thought:
      "No specific metric detected, so I'll pull a broad joined sample of recent orders to ground the answer in real rows.",
    sql: `SELECT o.id, c.name AS customer, p.name AS product, o.quantity, o.status, o.order_date
FROM orders o
JOIN customers c ON c.id = o.customer_id
JOIN products p ON p.id = o.product_id
ORDER BY o.order_date DESC
LIMIT 10`,
    answer: (rows) => `Here are the ${rows.length} most recent orders joined with customer and product details.`,
  };
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Runs the agent loop: inspect schema with tools, then query, then answer. */
export async function runAgent(
  question: string,
  onUpdate: (partial: Partial<AgentMessage>) => void,
): Promise<void> {
  const rawSql = question.trim();
  const isRawSql = /^(select|with)\s/i.test(rawSql);
  const plan = isRawSql
    ? {
        thought: "The input is already SQL, so I'll skip planning and execute it read-only.",
        sql: rawSql.replace(/;$/, ""),
        answer: (rows: Record<string, unknown>[]) => `Query executed — ${rows.length} row(s).`,
      }
    : planFor(question);

  const calls: ToolCall[] = [];
  const push = (call: ToolCall) => {
    calls.push(call);
    onUpdate({ toolCalls: [...calls] });
  };
  const settle = (call: ToolCall, result: Omit<ToolCall, "id" | "tool" | "input">) => {
    Object.assign(call, result);
    onUpdate({ toolCalls: [...calls] });
  };

  onUpdate({ thought: plan.thought });
  await sleep(320);

  if (!isRawSql) {
    const schemaCall: ToolCall = { id: uid(), tool: "list_tables", input: {}, status: "running" };
    push(schemaCall);
    await sleep(380);
    settle(schemaCall, executeTool("list_tables", {}));

    const referenced = [...new Set(plan.sql.match(/\b(?:from|join)\s+(\w+)/gi) ?? [])]
      .map((m) => m.split(/\s+/)[1]!.toLowerCase())
      .filter((t) => ["customers", "products", "orders"].includes(t));

    for (const table of referenced) {
      const call: ToolCall = { id: uid(), tool: "describe_table", input: { table }, status: "running" };
      push(call);
      await sleep(260);
      settle(call, executeTool("describe_table", { table }));
    }
  }

  const queryCall: ToolCall = { id: uid(), tool: "run_sql_query", input: { sql: plan.sql }, status: "running" };
  push(queryCall);
  await sleep(420);
  const result = executeTool("run_sql_query", { sql: plan.sql });
  settle(queryCall, result);

  if (result.status === "error") {
    onUpdate({ content: `The query failed: ${result.error}`, sql: plan.sql });
    return;
  }

  onUpdate({ content: plan.answer(result.rows ?? []), rows: result.rows ?? [], sql: plan.sql });
}
