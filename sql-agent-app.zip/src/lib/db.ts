import alasql from "alasql";

export type ColumnInfo = { name: string; type: string };
export type TableInfo = { name: string; columns: ColumnInfo[]; rows: number };

let ready = false;

const SCHEMA = `
CREATE TABLE customers (id INT, name STRING, country STRING, signup_date STRING);
CREATE TABLE products (id INT, name STRING, category STRING, price NUMBER);
CREATE TABLE orders (id INT, customer_id INT, product_id INT, quantity INT, order_date STRING, status STRING);
`;

const CUSTOMERS = [
  [1, "Ada Lovelace", "UK", "2024-01-12"],
  [2, "Grace Hopper", "USA", "2024-02-03"],
  [3, "Alan Turing", "UK", "2024-02-21"],
  [4, "Katherine Johnson", "USA", "2024-03-15"],
  [5, "Rina Sen", "India", "2024-04-02"],
  [6, "Luis Ortega", "Spain", "2024-04-28"],
  [7, "Mei Chen", "Singapore", "2024-05-19"],
  [8, "Jonas Berg", "Sweden", "2024-06-07"],
];

const PRODUCTS = [
  [1, "Mechanical Keyboard", "Peripherals", 149.0],
  [2, "27\" 4K Monitor", "Displays", 429.0],
  [3, "Noise Cancelling Headphones", "Audio", 299.5],
  [4, "USB-C Dock", "Peripherals", 189.99],
  [5, "Ergonomic Chair", "Furniture", 640.0],
  [6, "Standing Desk", "Furniture", 899.0],
  [7, "Webcam Pro", "Peripherals", 129.0],
];

const ORDERS: (string | number)[][] = [
  [1, 1, 2, 1, "2024-05-02", "shipped"],
  [2, 1, 1, 2, "2024-05-04", "shipped"],
  [3, 2, 5, 1, "2024-05-11", "pending"],
  [4, 3, 3, 1, "2024-05-14", "shipped"],
  [5, 4, 6, 1, "2024-06-01", "shipped"],
  [6, 5, 1, 3, "2024-06-09", "cancelled"],
  [7, 5, 4, 1, "2024-06-12", "shipped"],
  [8, 6, 7, 2, "2024-06-20", "pending"],
  [9, 7, 2, 2, "2024-07-01", "shipped"],
  [10, 8, 5, 1, "2024-07-04", "shipped"],
  [11, 2, 3, 2, "2024-07-09", "shipped"],
  [12, 3, 6, 1, "2024-07-18", "pending"],
  [13, 4, 1, 1, "2024-07-22", "shipped"],
  [14, 7, 4, 2, "2024-08-02", "shipped"],
  [15, 1, 5, 1, "2024-08-08", "cancelled"],
];

const COLUMNS: Record<string, ColumnInfo[]> = {
  customers: [
    { name: "id", type: "INT" },
    { name: "name", type: "STRING" },
    { name: "country", type: "STRING" },
    { name: "signup_date", type: "DATE" },
  ],
  products: [
    { name: "id", type: "INT" },
    { name: "name", type: "STRING" },
    { name: "category", type: "STRING" },
    { name: "price", type: "NUMBER" },
  ],
  orders: [
    { name: "id", type: "INT" },
    { name: "customer_id", type: "INT -> customers.id" },
    { name: "product_id", type: "INT -> products.id" },
    { name: "quantity", type: "INT" },
    { name: "order_date", type: "DATE" },
    { name: "status", type: "STRING" },
  ],
};

export function initDb() {
  if (ready) return;
  SCHEMA.split(";")
    .map((s) => s.trim())
    .filter(Boolean)
    .forEach((stmt) => alasql(stmt));

  alasql("INSERT INTO customers SELECT * FROM ?", [
    CUSTOMERS.map(([id, name, country, signup_date]) => ({ id, name, country, signup_date })),
  ]);
  alasql("INSERT INTO products SELECT * FROM ?", [
    PRODUCTS.map(([id, name, category, price]) => ({ id, name, category, price })),
  ]);
  alasql("INSERT INTO orders SELECT * FROM ?", [
    ORDERS.map(([id, customer_id, product_id, quantity, order_date, status]) => ({
      id,
      customer_id,
      product_id,
      quantity,
      order_date,
      status,
    })),
  ]);
  ready = true;
}

export function listTables(): TableInfo[] {
  initDb();
  return Object.keys(COLUMNS).map((name) => ({
    name,
    columns: COLUMNS[name]!,
    rows: (alasql(`SELECT COUNT(*) AS c FROM ${name}`) as { c: number }[])[0]!.c,
  }));
}

export function describeTable(name: string): TableInfo {
  const table = listTables().find((t) => t.name === name.toLowerCase());
  if (!table) throw new Error(`Unknown table "${name}"`);
  return table;
}

const FORBIDDEN = /\b(insert|update|delete|drop|alter|create|truncate|attach)\b/i;

export function runQuery(sql: string): Record<string, unknown>[] {
  initDb();
  const trimmed = sql.trim().replace(/;$/, "");
  if (!/^select\s|^with\s/i.test(trimmed)) throw new Error("Only SELECT queries are allowed.");
  if (FORBIDDEN.test(trimmed)) throw new Error("Write statements are blocked in read-only mode.");
  const result = alasql(trimmed) as unknown;
  return Array.isArray(result) ? (result as Record<string, unknown>[]) : [];
}
