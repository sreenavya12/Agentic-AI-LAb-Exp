import { createFileRoute } from "@tanstack/react-router";
import { SqlAgent } from "@/components/SqlAgent";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "SQL Agent — Ask your database in plain English" },
      {
        name: "description",
        content:
          "A React SQL agent that uses database tools to inspect schema, write SQL, and return answers from an in-browser sales database.",
      },
      { property: "og:title", content: "SQL Agent — Ask your database in plain English" },
      {
        property: "og:description",
        content: "Tool-using SQL agent: list tables, describe schema, run read-only queries, and see every step.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SqlAgent,
});
