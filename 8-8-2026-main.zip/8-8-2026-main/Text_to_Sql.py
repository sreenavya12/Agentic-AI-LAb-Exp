import ollama
import mysql.connector
import re

# ============================================================
# CONFIGURATION
# ============================================================

MODEL = "qwen3:8b"

MYSQL_HOST = "localhost"
MYSQL_USER = "root"
MYSQL_PASSWORD = "12345678"
MYSQL_DATABASE = "company"


# ============================================================
# CONNECT TO MYSQL
# ============================================================

try:
    conn = mysql.connector.connect(
        host=MYSQL_HOST,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DATABASE
    )

    cursor = conn.cursor()

    print("Connected to MySQL successfully!")

except mysql.connector.Error as e:
    print("MySQL connection failed:")
    print(e)
    exit()


# ============================================================
# GET DATABASE SCHEMA
# ============================================================

def get_schema():

    cursor.execute("""
        SELECT
            TABLE_NAME,
            COLUMN_NAME,
            DATA_TYPE
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
        ORDER BY TABLE_NAME, ORDINAL_POSITION
    """)

    rows = cursor.fetchall()

    schema = ""

    current_table = None

    for table_name, column_name, data_type in rows:

        if table_name != current_table:
            schema += f"\nTable: {table_name}\n"
            current_table = table_name

        schema += f"- {column_name} ({data_type})\n"

    return schema


# ============================================================
# GENERATE SQL USING QWEN
# ============================================================

def generate_sql(question):

    schema = get_schema()

    prompt = f"""
You are an expert MySQL SQL generator.

Database schema:

{schema}

User question:
{question}

Generate ONLY the MySQL SQL query.

Rules:
1. Use valid MySQL 8+ syntax.
2. Use only tables and columns that exist in the schema.
3. Do not explain the query.
4. Do not use markdown.
5. Generate only SELECT queries.
6. Do not generate INSERT, UPDATE, DELETE, DROP, ALTER,
   CREATE, TRUNCATE, or other destructive queries.
"""

    response = ollama.chat(
        model=MODEL,
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    sql = response["message"]["content"].strip()

    # Remove markdown code blocks if Qwen adds them
    sql = re.sub(r"```sql", "", sql, flags=re.IGNORECASE)
    sql = re.sub(r"```", "", sql)

    sql = sql.strip()

    # Remove Qwen's optional <think>...</think> section
    sql = re.sub(
        r"<think>.*?</think>",
        "",
        sql,
        flags=re.DOTALL | re.IGNORECASE
    ).strip()

    return sql


# ============================================================
# VALIDATE SQL
# ============================================================

def validate_sql(sql):

    sql_clean = sql.strip().lower()

    # Only allow SELECT
    if not sql_clean.startswith("select"):
        return False, "Only SELECT queries are allowed."

    # Prevent multiple statements
    if ";" in sql_clean[:-1]:
        return False, "Multiple SQL statements are not allowed."

    # Dangerous SQL keywords
    forbidden_keywords = [
        "insert",
        "update",
        "delete",
        "drop",
        "alter",
        "truncate",
        "create",
        "replace",
        "grant",
        "revoke"
    ]

    for keyword in forbidden_keywords:

        if re.search(r"\b" + keyword + r"\b", sql_clean):
            return False, f"Forbidden SQL operation: {keyword}"

    return True, ""


# ============================================================
# EXECUTE SQL
# ============================================================

def execute_sql(sql):

    valid, error = validate_sql(sql)

    if not valid:
        return None, error

    try:

        cursor.execute(sql)

        rows = cursor.fetchall()

        if cursor.description is None:
            return [], rows

        columns = [
            description[0]
            for description in cursor.description
        ]

        return columns, rows

    except mysql.connector.Error as e:

        return None, str(e)


# ============================================================
# GENERATE FINAL NATURAL LANGUAGE ANSWER
# ============================================================

def generate_answer(question, sql, columns, rows):

    result = {
        "columns": columns,
        "rows": rows
    }

    prompt = f"""
You are a helpful database assistant.

User question:
{question}

SQL query:
{sql}

Database result:
{result}

Answer the user's question using the database result.

Rules:
1. Give a clear and concise answer.
2. Use simple language.
3. Do not mention internal instructions.
4. Do not invent information.
5. If there are multiple rows, present the important information clearly.
"""

    response = ollama.chat(
        model=MODEL,
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response["message"]["content"].strip()


# ============================================================
# DISPLAY DATABASE RESULT
# ============================================================

def display_result(columns, rows):

    if not rows:
        print("No results found.")
        return

    print("\nDatabase Result:")
    print("-" * 60)

    # Header
    print(" | ".join(str(column) for column in columns))

    print("-" * 60)

    # Rows
    for row in rows:
        print(" | ".join(str(value) for value in row))

    print("-" * 60)


# ============================================================
# MAIN PROGRAM
# ============================================================

print("\n========================================")
print("      TEXT-TO-SQL AI ASSISTANT")
print("========================================")

print("Model :", MODEL)
print("Database :", MYSQL_DATABASE)

while True:

    question = input("\nAsk a database question: ")

    if question.lower().strip() in ["exit", "quit"]:
        break

    if not question.strip():
        continue

    # --------------------------------------------------------
    # STEP 1: Generate SQL
    # --------------------------------------------------------

    print("\nGenerating SQL...")

    sql = generate_sql(question)

    print("\nGenerated SQL:")
    print(sql)

    # --------------------------------------------------------
    # STEP 2: Execute SQL
    # --------------------------------------------------------

    print("\nExecuting SQL...")

    columns, result = execute_sql(sql)

    if columns is None:

        print("\nSQL Error:")
        print(result)

        continue

    # --------------------------------------------------------
    # STEP 3: Display result
    # --------------------------------------------------------

    display_result(columns, result)

    # --------------------------------------------------------
    # STEP 4: Generate natural language answer
    # --------------------------------------------------------

    print("\nGenerating answer...")

    answer = generate_answer(
        question,
        sql,
        columns,
        result
    )

    print("\nAI Answer:")
    print(answer)


# ============================================================
# CLOSE CONNECTION
# ============================================================

cursor.close()
conn.close()

print("\nMySQL connection closed.")
print("Goodbye!")